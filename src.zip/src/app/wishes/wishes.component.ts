import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-wishes',
  templateUrl: './wishes.component.html',
  styleUrls: ['./wishes.component.css']
})
export class WishesComponent implements OnInit {

  constructor(private route: ActivatedRoute) { }

  name : any = "";
  answer : any = "";
  isAnswer : boolean = false;
  isError  : boolean = false;

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.name = params['id'];
    });
    console.log(this.name); 
  }

  validation(){
    if(this.name=='Sunny' && this.answer.toLowerCase().trim()=='cricket'){
      this.isAnswer=true
    }
    if(this.name=='Stefan' && this.answer.toLowerCase().trim()=='miku'){
      this.isAnswer=true
    }
    if(this.name=='Chotu' && this.answer.toLowerCase().trim()=='radhika'){
      this.isAnswer=true
    }
    if(this.name=='Anurag' && this.answer.toLowerCase().trim()=='tree'){
      this.isAnswer=true
    }
    if(this.name=='Sumit' && this.answer.toLowerCase().trim()=='ladnun'){
      this.isAnswer=true
    }
    if(this.name=='Vandu' && this.answer.toLowerCase().trim()=='jaatbhai'){
      this.isAnswer=true
    }
    if(this.name=='Puneet' && this.answer.toLowerCase().trim()=='prajakta'){
      this.isAnswer=true
    }
    if(this.name=='Osu' && this.answer.toLowerCase().trim()=='hoegaarden'){
      this.isAnswer=true
    }
    if(this.name=='D' && this.answer.toLowerCase().trim()=='jd'){
      this.isAnswer=true
    }
    if(this.name=='Virus' && this.answer.toLowerCase().trim()=='nothing much'){
      this.isAnswer=true
    }
    if(this.name=='Snehal' && this.answer.toLowerCase().trim()=='northern lights'){
      this.isAnswer=true
    }
    if(this.name=='Prateek' && this.answer.toLowerCase().trim()=='rooh'){
      this.isAnswer=true
    }
    if(this.name=='Arif' && this.answer.toLowerCase().trim()=='arif'){
      this.isAnswer=true
    }
    if(this.name=='Antim' && this.answer.toLowerCase().trim()=='priya'){
      this.isAnswer=true
    }
    if(this.name=='Swati' && this.answer.toLowerCase().trim()=='sumi'){
      this.isAnswer=true
    }
    if(this.name=='Arun' && this.answer.toLowerCase().trim()=='kanuta'){
      this.isAnswer=true
    }
    if(this.name=='Sonali' && this.answer.toLowerCase().trim()=='sweater'){
      this.isAnswer=true
    }
    if(this.name=='Amit' && this.answer.toLowerCase().trim()=='60000'){
      this.isAnswer=true
    }
    if(this.name=='Anonymous' && this.answer.toLowerCase().trim()=='nasir'){
      this.isAnswer=true
    }
    if(this.name=='Moni' && this.answer.toLowerCase().trim()=='junction'){
      this.isAnswer=true
    }
    if(this.name=='Praju' && this.answer.toLowerCase().trim()=='ahmedabad'){
      this.isAnswer=true
    }
    if(this.name=='Dhana' && this.answer.toLowerCase().trim()=='apple'){
      this.isAnswer=true
    }
    if(this.name=='Yami' && this.answer.toLowerCase().trim()=='taunt'){
      this.isAnswer=true
    }
    if(this.name=='Buddy' && this.answer.toLowerCase().trim()=='marine'){
      this.isAnswer=true
    }
    else{
      this.isError=true;
    }
  }

}
