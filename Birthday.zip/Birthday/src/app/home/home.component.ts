import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  imageNumber = 1;
  
  ngOnInit(): void {
  }

  funcPrevious(){
    if(this.imageNumber==1){
      this.imageNumber=3;
    }
    else if(this.imageNumber==2){
      this.imageNumber=1;
    }
    else if(this.imageNumber==3){
      this.imageNumber=2
    }
  }

  funcNext(){
    if(this.imageNumber==1){
      this.imageNumber=2;
    }
    else if(this.imageNumber==2){
      this.imageNumber=3;
    }
    else if(this.imageNumber==3){
      this.imageNumber=1
    }
  }

}
